package jogo_velha;

import java.util.Scanner; //Pra poder ler a entrada do console



public class Fronteira {

	public static Controle controle = new Controle();
	static Menu_Jogo_Velha menu = new Menu_Jogo_Velha();
	static Scanner input = new Scanner(System.in);

	/*
	 * Coloquei em um método o case q tinha as interfaces e em uma outra classe
	 * coloquei os níveis..qdo a pessoa escolher o nivel.. pra qualquer opcao
	 * ele inicia a partida
	 */

	public static void imprimeTabuleiro(char matriz[][]) {
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				System.out.print(matriz[i][j]);
			}
			System.out.println();
		}
	}

	public static void nivelJogo() {// Jogador escolhe o nível do jogo em que
									// quer jogar

		int opcao;

		do {
			Menu_Jogo_Velha.displayNiveis();
			opcao = input.nextInt();

			switch (opcao) {
			case Menu_Jogo_Velha.FACIL:
				System.out.println("Ainda nao dispon�vel...");
				//iniciarPartida();
				break;

			case Menu_Jogo_Velha.MEDIO:
				System.out.println("Ainda nao dispon�vel...");
				//iniciarPartida();
				break;

			case Menu_Jogo_Velha.DIFICIL:
				System.out.println("Ainda nao dispon�vel...");
				//iniciarPartida();
				break;

			case Menu_Jogo_Velha.VOLTARNIVEL:
				break;

			default:
				System.out.println("OPCAO INV�LIDA!");
				break;
			}

		} while (opcao != Menu_Jogo_Velha.VOLTARNIVEL);

	}

	public static void interfaceTexto() {
		int opcao;

		do {
			Menu_Jogo_Velha.displayOponente();// aqui o jogador vai escolher o
												// tipo de oponente
			opcao = input.nextInt();

			switch (opcao) {
			case Menu_Jogo_Velha.OPONENTE_HUMANO:
				iniciarPartida();
				imprimeTabuleiro(Entidade.getMatriz());
				break;

			case Menu_Jogo_Velha.OPONENTE_ROBO:
				nivelJogo();

				break;

			case Menu_Jogo_Velha.VOLTAR:
				break;

			default:

				System.out.println("OPCAO INV�LIDA!");
				break;
			}

		} while (opcao != Menu_Jogo_Velha.VOLTAR);
	}

	public static void menuPrincipal() {

		int opcao1, opcao2;

		do {
			Menu_Jogo_Velha.displayMenu();
			opcao1 = input.nextInt();

			switch (opcao1) {

			case Menu_Jogo_Velha.TIPO_INTERFACE:

				do {
					Menu_Jogo_Velha.displayMenuInterface();
					opcao2 = input.nextInt();

					switch (opcao2) {

					case Menu_Jogo_Velha.INTERFACE_GRAFICA:
						System.out.println("Interface n�o dispon�vel\n");
						break;

					case Menu_Jogo_Velha.INTERFACE_TEXTO:
						interfaceTexto();

						break;

					case Menu_Jogo_Velha.VOLTAR:
						break;

					default:

						System.out.println("OPCAO INV�LIDA!");
						break;
					}
				} while (opcao2 != Menu_Jogo_Velha.VOLTAR);
				break;

			case Menu_Jogo_Velha.SAIR:
				break;

			default:
				System.out.println("OPCAO INV�LIDA!");
				break;
			}
		} while (opcao1 != Menu_Jogo_Velha.SAIR);
	}

	public static void iniciarPartida() {
		int i,j;
		char simbolo = 'x';
		iniciaTabuleiro();
		while (controle.jogoTerminado() != true) {
			imprimeTabuleiro(Controle.getMatriz());
			System.out.println("\nDigite a linha e a coluna de sua jogada: ");
			i = input.nextInt();
			j = input.nextInt();
			if(controle.validaJogada(i, j)){
				Jogar(i,j,simbolo);
				if (simbolo == 'x')
					simbolo = 'o';
				else
					simbolo='x';
			}
			else
				System.out.println("Posição inválida");
					
		}

	}
	public static void iniciaTabuleiro(){
		controle.iniciaTabuleiro();
	}

	public static void Jogar(int i, int j, char simbolo) {

		// if (metodo que valida jogada for na entidade e retornar True); entao
		//Esse metodo tem que ver se a escolha ja existe e se esta livre...
		//qqr duvida depois fazemos...
		// faca
		controle.fazerJogada(i, j, simbolo);
	}

	public static void main(String[] args) {

		menuPrincipal();
	}

}