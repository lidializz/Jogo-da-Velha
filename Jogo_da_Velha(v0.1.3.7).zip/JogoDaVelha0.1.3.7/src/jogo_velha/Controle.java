package jogo_velha;

public class Controle {

	static char[][] matriz = new char[5][5];

	static Entidade entidade = new Entidade();

	public static char[][] getMatriz() {
		matriz = Entidade.getMatriz();
		return matriz;
	}

	public void limparTabuleiro() {

	}

	public boolean jogoTerminado() {
		if (entidade.fimJogo())
			return true;
		else
			return false;
	}
	public void iniciaTabuleiro(){
		entidade.Tabuleiro();
	}

	public void fazerJogada(int i, int j, char simbolo) {
		entidade.marcarJogada(i, j, simbolo);
	}
	
	public boolean validaJogada(int i, int j){
		if(!entidade.verificaPosicaoInvalida(i, j))
			return true;
		else
			return false;
		
		
	}

}
