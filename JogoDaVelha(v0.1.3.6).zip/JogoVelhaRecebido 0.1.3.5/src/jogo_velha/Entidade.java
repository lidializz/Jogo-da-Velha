package jogo_velha;

//import java.util.Scanner;

public class Entidade {
	
	static char[][] matriz = new char[5][5];
		
	public void iniciarPartida(){
		jogar();
	}
	

	public static char[][] getMatriz() {
		return matriz;
	}


	private void jogar() {
		//Scanner input = new Scanner(System.in);
		//int jogador1 = 1;
		//int jogador2 = 2;
		//gerarTabuleiro(matriz);
		inicializarTabuleiro(matriz);
		for(int i=0; i<9; i++){
			//le as entradas dos jogadores com o uso do Scanner...
		}
		
	}
	
	public static void inicializarTabuleiro(char matriz[][]){
		for(int i=0; i<5; i=i+2){
			matriz[i][1] = '|';
			matriz[i][3] = '|';
		}
		for(int i=0; i<5; i++){
			matriz[1][i]='-';
			matriz[3][i]='-';
		}
		limparPosicoes(matriz);		
	}
	
	public void Tabuleiro(){
		inicializarTabuleiro(matriz);
	}
	
	public void marcarJogada(int i, int j, char simbolo){
		i = (i-1)*2;
		j = (j-1)*2;
		matriz[i][j] = simbolo;
	}
	
	public boolean fimJogo(){
		if (((matriz[0][0] != ' ')&&(matriz[0][0] == matriz[0][2]) &&(matriz[0][2]== matriz[0][4])) || 
			((matriz[2][0] != ' ')&&(matriz[2][0] == matriz[2][2]) &&(matriz[2][2]== matriz[2][4])) ||	
			((matriz[4][0] != ' ')&&(matriz[4][0] == matriz[4][2]) &&(matriz[4][2]== matriz[4][4])) ||
			((matriz[0][0] != ' ')&&(matriz[0][0] == matriz[2][0]) &&(matriz[2][0]== matriz[4][0])) || 
			((matriz[0][2] != ' ')&&(matriz[0][2] == matriz[2][2]) &&(matriz[2][2]== matriz[4][2])) ||	
			((matriz[0][4] != ' ')&&(matriz[0][4] == matriz[2][4]) &&(matriz[2][4]== matriz[4][4])) ||
			((matriz[0][0] != ' ')&&(matriz[0][0] == matriz[2][2]) &&(matriz[2][2]== matriz[4][4])) ||	
			((matriz[4][0] != ' ')&&(matriz[4][0] == matriz[2][2]) &&(matriz[2][2]== matriz[0][4])) )
			return true;
		else
			return false;
	}
	
	public static void limparPosicoes(char matriz[][]){
		for (int i=0; i< 5; i=i+2){
			for (int j=0; j<5; j=j+2){
				matriz[i][j]=' ';
			}
				
		}
	
	}
			
}
