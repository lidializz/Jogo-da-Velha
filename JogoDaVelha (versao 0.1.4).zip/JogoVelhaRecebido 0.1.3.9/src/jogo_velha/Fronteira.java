package jogo_velha;

import java.util.Scanner; //Pra poder ler a entrada do console

public class Fronteira {

	public static Controle controle = new Controle();
	static Menu_Jogo_Velha menu = new Menu_Jogo_Velha();
	static Scanner input = new Scanner(System.in);

	/*
	 * Coloquei em um m�todo o case q tinha as interfaces e em uma outra classe
	 * coloquei os n�veis..qdo a pessoa escolher o nivel.. pra qualquer opcao
	 * ele inicia a partida
	 */

	public static void imprimeTabuleiro(char matriz[][]) {
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				System.out.print(matriz[i][j]);
			}
			System.out.println();
		}
	}

	public static void nivelJogo() {// Jogador escolhe o n�vel do jogo em que
		// quer jogar

		int opcao;

		do {
			Menu_Jogo_Velha.displayNiveis();
			opcao = input.nextInt();

			switch (opcao) {
			case Menu_Jogo_Velha.FACIL:
				System.out.println("Ainda nao disponivel...");
				// iniciarPartida();
				break;

			case Menu_Jogo_Velha.MEDIO:
				System.out.println("Ainda nao disponivel...");
				// iniciarPartida();
				break;

			case Menu_Jogo_Velha.DIFICIL:
				System.out.println("Ainda nao disponivel...");
				// iniciarPartida();
				break;

			case Menu_Jogo_Velha.VOLTARNIVEL:
				break;

			default:
				System.out.println("OPCAO INVALIDA!");
				break;
			}

		} while (opcao != Menu_Jogo_Velha.VOLTARNIVEL);

	}

	public static void interfaceTexto() {
		int opcao;

		do {
			Menu_Jogo_Velha.displayOponente();// aqui o jogador vai escolher o
			// tipo de oponente
			opcao = input.nextInt();

			switch (opcao) {
			case Menu_Jogo_Velha.OPONENTE_HUMANO:
				iniciarPartida();
				break;

			case Menu_Jogo_Velha.OPONENTE_ROBO:
				nivelJogo();

				break;

			case Menu_Jogo_Velha.VOLTAR:
				break;

			default:

				System.out.println("OPCAO INVALIDA!");
				break;
			}

		} while (opcao != Menu_Jogo_Velha.VOLTAR);
	}

	public static void menuPrincipal() {

		int opcao1, opcao2;

		do {
			Menu_Jogo_Velha.displayMenu();
			opcao1 = input.nextInt();

			switch (opcao1) {

			case Menu_Jogo_Velha.TIPO_INTERFACE:

				do {
					Menu_Jogo_Velha.displayMenuInterface();
					opcao2 = input.nextInt();

					switch (opcao2) {

					case Menu_Jogo_Velha.INTERFACE_GRAFICA:
						System.out.println("Interface nao disponivel\n");
						break;

					case Menu_Jogo_Velha.INTERFACE_TEXTO:
						interfaceTexto();

						break;

					case Menu_Jogo_Velha.VOLTAR:
						break;

					default:

						System.out.println("OPCAO INVALIDA!");
						break;
					}
				} while (opcao2 != Menu_Jogo_Velha.VOLTAR);
				break;

			case Menu_Jogo_Velha.SAIR:
				break;

			default:
				System.out.println("OPCAO INVALIDA!");
				break;
			}
		} while (opcao1 != Menu_Jogo_Velha.SAIR);
	}

	public static void iniciarPartida() {
		int i, j;
		char simbolo = 'x';
		iniciaTabuleiro();
		while ((controle.jogoTerminado() != true)
				&& (controle.verificaTabuleiroCheio() != true)) {
			imprimeTabuleiro(Controle.getMatriz());
			System.out.println("\nDigite a linha e a coluna de sua jogada: ");
			i = input.nextInt();
			j = input.nextInt();

			if (Jogar(i, j, simbolo)) {
				if (simbolo == 'x')
					simbolo = 'o';
				else
					simbolo = 'x';
			}
		}
		imprimeTabuleiro(Controle.getMatriz());
		if (controle.jogoTerminado() == true)
			if (simbolo == 'x')
				System.out.println("\nO jogador 2 venceu!\n");
			else
				System.out.println("\nO jogador 1 venceu!\n");
		else
			System.out.println("\nEmpate!\n");

	}

	public static void iniciaTabuleiro() {
		controle.iniciaTabuleiro();
	}

	public static boolean Jogar(int i, int j, char simbolo) {

		if (controle.validaJogada(i, j) == true) {
			if (controle.posicaoOcupada(i, j) == false) {
				controle.fazerJogada(i, j, simbolo);
				return true;
			} else
				System.out.println("\nPosi��o ja ocupada! Jogue novamente...");
			return false;
		} else
			System.out.println("\nPosi��o inv�lida");
		return false;
	}

	public static void main(String[] args) {

		menuPrincipal();
	}

}
