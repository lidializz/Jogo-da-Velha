package jogo_velha;

public class Entidade {
	
	public void set_ui(){
		
	}

}
