package jogo_velha;

import java.util.Scanner; //Pra poder ler a entrada do console

public class Fronteira {
	
	public static Controle controle = new Controle();
	static Menu_Jogo_Velha menu = new Menu_Jogo_Velha();
	static Scanner input = new Scanner(System.in);
	
	public static void menuPrincipal(){
		
		int opcao;
			
		do {
				opcao = input.nextInt();
				
				switch(opcao) {
				
					case Menu_Jogo_Velha.TIPO_INTERFACE:
						controle.ctrl_selecionar_ui(opcao);
						break;
							
					case Menu_Jogo_Velha.SAIR:
						break;
										
					default:
						System.out.println("OPCAO INV�LIDA!");
						break;
				}
			} while (opcao != menu.SAIR);
		}

	

	public static void main(String[] args) {
		
		Menu_Jogo_Velha.display();
		menuPrincipal();
		controle.ctrl_selecionar_ui(menu.display());
	   
		
	}

}
