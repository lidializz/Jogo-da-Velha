package jogo_velha;

import javax.swing.JOptionPane;

public class Fronteira {
	
	public static Controle controle = new Controle();
	static Menu_Jogo_Velha menu = new Menu_Jogo_Velha();
	
	public static void menuPrincipal(){
		
		int opcao;
			
		do {
				opcao = menu.display();

				switch(opcao) {
				
					case Menu_Jogo_Velha.TIPO_INTERFACE:
						controle.ctrl_selecionar_ui(opcao);
						break;
							
					case Menu_Jogo_Velha.SAIR:
						break;
										
					default:
						JOptionPane.showMessageDialog(null, "OPCAO INVÁLIDA!");
						break;
				}
			} while (opcao != menu.SAIR);
		}

	

	public static void main(String[] args) {
		
		menuPrincipal();
		controle.ctrl_selecionar_ui(menu.display());
	   
		
	}

}
