package jogo_velha;

import javax.swing.JOptionPane;

public class Menu_Jogo_Velha {
	
	public static final int TIPO_INTERFACE = 1;
	public static final int SAIR = 2;
	public static final int INTERFACE_GRAFICA = 1;
	public static final int INTERFACE_TEXTO = 2;
	public static final int VOLTAR = 3;
	
	
	private static String menuStr;
	
	private static void montaMenu(){
		menuStr = "JOGO DA VELHA JLW\n\n"
				+ "Digite a opção desejada:\n"
				+ "1 - Tipo de interface\n"
				+ "2 - Sair";
	}
	private static void montaMenuInterface(){
		menuStr = "JOGO DA VELHA JLW\n\n"
				+ "Digite a opção desejada:\n"
				+ "1 - Interface Gráfica\n"
				+ "2 - Interface Texto\n"
				+ "3 - Voltar";
	}
	
	public static int display(){
	
		montaMenu();
				
		int opcao = new Integer( JOptionPane.showInputDialog(menuStr) );
		
		if(opcao == 1){
			montaMenuInterface();
			int opcao2 = new Integer( JOptionPane.showInputDialog(menuStr) );
			
			if(opcao2 == 3){
				display();		
		}
			return opcao2;
		
		}
	
	return opcao;
}
}
		
		
		

