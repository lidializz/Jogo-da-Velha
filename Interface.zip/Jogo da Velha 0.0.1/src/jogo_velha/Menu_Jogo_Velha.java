package jogo_velha;

import java.util.Scanner;

public class Menu_Jogo_Velha {

	public static final int TIPO_INTERFACE = 1;
	public static final int SAIR = 2;
	public static final int INTERFACE_GRAFICA = 1;
	public static final int INTERFACE_TEXTO = 2;
	public static final int VOLTAR = 3;
	public static int opcao;
	public static int opcao2;

	// Fiz essa nomeaçao abaixo pq nao tinha muito tempo... pra funcionar tbm

	static String menuStr = "\nJOGO DA VELHA JLW\n\n"
			+ "Digite a opção desejada:\n" 
			+ "1 - Tipo de interface\n"
			+ "2 - Sair";
	static String menuInterfaceStr = "\nJOGO DA VELHA JLW\n\n"
			+ "Digite a opçao desejada:\n" + "1 - Interface Gráfica\n"
			+ "2 - Interface Texto\n" + "3 - Voltar";

	static Scanner input = new Scanner(System.in);

	// Eu comentei mas deixei pro caso de ser necessário depois essa parte
	
	 /*private static void montaMenu() { menuStr = "JOGO DA VELHA JLW\n\n" +
	 "Digite a opção desejada:\n" + "1 - Tipo de interface\n" + "2 - Sair"; }
	  
	  private static void montaMenuInterface() { menuInterfaceStr =
	  "JOGO DA VELHA JLW\n\n" + "Digite a opção desejada:\n" +
	  "1 - Interface Gráfica\n" + "2 - Interface Texto\n" + "3 - Voltar"; }
	 */
	  public static int display1() {

		System.out.println(menuStr);

		int opcao = input.nextInt();

		return opcao;
	}
	  
	  public static int display2() {

			System.out.println(menuInterfaceStr);

			int opcao = input.nextInt();
		

			return opcao;
		}
	
	

}
