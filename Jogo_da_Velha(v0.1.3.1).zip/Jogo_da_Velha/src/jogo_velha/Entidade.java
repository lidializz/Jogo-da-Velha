package jogo_velha;

public class Entidade {
	
	static int[][] matriz = new int[3][3];
	
	public void set_ui(){
		
	}

	public void set_oponente() {
		
		
		
		
		
	}
	
	
	public void iniciarPartida(){
		limparPosicoes();
		gerarTabuleiro();
		jogar();
	
	}
	

	private void jogar() {
		
	}

	public void limparPosicoes(){
		
	
	}
	

	public void gerarTabuleiro(){
		
	
	}

}
