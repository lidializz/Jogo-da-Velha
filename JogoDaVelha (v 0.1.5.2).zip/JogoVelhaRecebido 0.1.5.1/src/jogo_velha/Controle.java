package jogo_velha;

public class Controle {

	static char[][] matriz = new char[5][5];

	static Entidade entidade = new Entidade();

	public static char[][] getMatriz() {
		matriz = Entidade.getMatriz();
		return matriz;
	}

	public boolean jogoTerminado() {
		if (entidade.fimJogo() == true)
			return true;
		else
			return false;
	}
	
	public void jogaRobo() {
		entidade.jogadaRobo();
	}

	public void iniciaTabuleiro() {
		entidade.Tabuleiro();
	}

	public void fazerJogada(int i, int j, char simbolo) {
		entidade.marcarJogada(i, j, simbolo);
	}
	
	public boolean roboGanhou(){
		if (entidade.roboVenceu() == true)
			return true;
		else
			return false;
	}

	public boolean validaJogada(int i, int j) {
		if (entidade.verificaPosicaoInvalida(i, j) == true)
			return false;
		else
			return true;

	}

	public boolean posicaoOcupada(int i, int j) {
		if (entidade.verificaPosicaoOcupada(i, j) == true)
			return true;
		else
			return false;
	}

	public boolean verificaTabuleiroCheio() {
		if (entidade.verificaTabuleiroOcupado() == true)
			return true;
		else
			return false;

	}

}
