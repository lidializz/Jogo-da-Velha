package jogo_velha;

import java.util.Scanner; //Pra poder ler a entrada do console

public class Fronteira {

	public static Controle controle = new Controle();
	static Menu_Jogo_Velha menu = new Menu_Jogo_Velha();
	static Scanner input = new Scanner(System.in);

	/*
	 * Coloquei em um metodo o case q tinha as interfaces e em uma outra classe
	 * coloquei os niveis..qdo a pessoa escolher o nivel.. pra qualquer opcao
	 * ele inicia a partida
	 */

	public static void imprimeTabuleiro(char matriz[][]) {
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				System.out.print(matriz[i][j]);
			}
			System.out.println();
		}
	}

	public static void interfaceTexto() {
		int opcao;

		do {
			Menu_Jogo_Velha.displayOponente();// aqui o jogador vai escolher o
			// tipo de oponente
			opcao = input.nextInt();

			switch (opcao) {
			case Menu_Jogo_Velha.OPONENTE_HUMANO:
				iniciarPartida(1);
				break;

			case Menu_Jogo_Velha.OPONENTE_ROBO:
				nivelJogo();
				break;

			case Menu_Jogo_Velha.VOLTAR:
				break;

			default:

				System.out.println("OPCAO INVALIDA!");
				break;
			}

		} while (opcao != Menu_Jogo_Velha.VOLTAR);
	}

	public static void nivelJogo() {// Jogador escolhe o nivel do jogo em que
		// quer jogar

		int opcao;

		do {
			Menu_Jogo_Velha.displayNiveis();
			opcao = input.nextInt();

			switch (opcao) {
			case Menu_Jogo_Velha.FACIL:
				iniciarPartida(2);
				break;

			case Menu_Jogo_Velha.MEDIO:
				iniciarPartida(2);
				break;

			case Menu_Jogo_Velha.DIFICIL:
				iniciarPartida(2);
				break;

			case Menu_Jogo_Velha.VOLTARNIVEL:
				break;

			default:
				System.out.println("OPCAO INVALIDA!");
				break;
			}

		} while (opcao != Menu_Jogo_Velha.VOLTARNIVEL);

	}

	public static void menuPrincipal() {

		int opcao1, opcao2;

		do {
			Menu_Jogo_Velha.displayMenu();
			opcao1 = input.nextInt();

			switch (opcao1) {

			case Menu_Jogo_Velha.TIPO_INTERFACE:

				do {
					Menu_Jogo_Velha.displayMenuInterface();
					opcao2 = input.nextInt();

					switch (opcao2) {

					case Menu_Jogo_Velha.INTERFACE_GRAFICA:
						System.out.println("Interface nao disponivel\n");
						break;

					case Menu_Jogo_Velha.INTERFACE_TEXTO:
						interfaceTexto();

						break;

					case Menu_Jogo_Velha.VOLTAR:
						break;

					default:

						System.out.println("OPCAO INVALIDA!");
						break;
					}
				} while (opcao2 != Menu_Jogo_Velha.VOLTAR);
				break;

			case Menu_Jogo_Velha.SAIR:
				break;

			default:
				System.out.println("OPCAO INVALIDA!");
				break;
			}
		} while (opcao1 != Menu_Jogo_Velha.SAIR);
	}

	public static void iniciaTabuleiro() {
		controle.iniciaTabuleiro();
	}

	public static void reiniciar() { // neste metodo o jogador pode escolher pra
		// qual menu voltar
		int k = 3;
		System.out
				.println("Digite 0 para voltar ao menu principal ou 1 para iniciar uma nova partida");
		k = input.nextInt();
		if (k == 0) 
			menuPrincipal();
		else 
			interfaceTexto();
	}

	public static void jogadorHumano() {
		int i, j;
		char simbolo = 'x';
		iniciaTabuleiro();
		while ((controle.jogoTerminado() != true)
				&& (controle.verificaTabuleiroCheio() != true)) {
			imprimeTabuleiro(Controle.getMatriz());

			if (simbolo == 'x')
				System.out.println("\n\nJogador 1\n");
			else
				System.out.println("\n\nJogador 2\n");

			System.out.println("Digite a linha e a coluna de sua jogada: ");
			i = input.nextInt();
			j = input.nextInt();

			if (Jogar(i, j, simbolo)) {
				if (simbolo == 'x')
					simbolo = 'o';
				else
					simbolo = 'x';
			}
		}
		imprimeTabuleiro(Controle.getMatriz());
		if (controle.jogoTerminado() == true)
			if (simbolo == 'x')
				System.out.println("\nO jogador 2 venceu!\n");
			else
				System.out.println("\nO jogador 1 venceu!\n");
		else
			System.out.println("\nVelhouuu :p!\n");

		reiniciar();

	}

	public static void jogadorRobo() {
		int i, j;
		char simbolo = 'x';
		iniciaTabuleiro();
		while ((controle.jogoTerminado() != true)
				&& (controle.verificaTabuleiroCheio() != true)) {
			imprimeTabuleiro(Controle.getMatriz());
			System.out.println("\n\nJogador Humano\n");

			System.out.println("Digite a linha e a coluna de sua jogada: ");
			i = input.nextInt();
			j = input.nextInt();

			if (Jogar(i, j, simbolo)) {
				if ((controle.verificaTabuleiroCheio() != true)
						&& (controle.jogoTerminado() != true))
					controle.jogaRobo();
			}
		}
		imprimeTabuleiro(Controle.getMatriz());
		if (controle.jogoTerminado() == true) {
			if (controle.roboGanhou() == true)
				System.out.println("\nO jogador computador venceu!\n");
			else
				System.out.println("\nO jogador humano venceu!\n");
		} else
			System.out.println("\nVelhouuu :p!\n");

		reiniciar();
	}

	public static void iniciarPartida(int opcao) {

		iniciaTabuleiro();
		if (opcao == 1)
			jogadorHumano();
		else
			jogadorRobo();
	}

	public static boolean Jogar(int i, int j, char simbolo) {

		if (controle.validaJogada(i, j) == true) {
			if (controle.posicaoOcupada(i, j) == false) {
				controle.fazerJogada(i, j, simbolo);
				return true;
			} else
				System.out
						.println("\n\nPosicao ja ocupada! Jogue novamente...\n\n");
			return false;
		} else
			System.out.println("\n\nPosicao invalida\n\n");
		return false;
	}

	public static void main(String[] args) {

		menuPrincipal();
	}

}
