package jogo_velha;

import java.util.Scanner; //Pra poder ler a entrada do console

public class Fronteira {
	
	public static Controle controle = new Controle();
	static Menu_Jogo_Velha menu = new Menu_Jogo_Velha();
	static Scanner input = new Scanner(System.in);
	
	
	public static void menuSecundario(){
		
		do {		
		
		switch(Menu_Jogo_Velha.display2()) {
		
		case Menu_Jogo_Velha.INTERFACE_GRAFICA:
				break;
				
		case Menu_Jogo_Velha.INTERFACE_TEXTO:
			break;
			
			
		case Menu_Jogo_Velha.VOLTAR:
			menu.display1();
			break;
							
		default:
			System.out.println("OPCAO INVÁLIDA!");
			break;
	}
		
		} while (Menu_Jogo_Velha.display2() != menu.VOLTAR);
		
	}
	
	
	
	
	public static void menuPrincipal(){
		
		do {
			
				
				switch(Menu_Jogo_Velha.display1()) {
				
					case Menu_Jogo_Velha.TIPO_INTERFACE:
						controle.ctrl_selecionar_ui(Menu_Jogo_Velha.display1());
						menuSecundario();
						break;
							
					case Menu_Jogo_Velha.SAIR:
						break;
										
					default:
						System.out.println("OPCAO INVÁLIDA!");
						break;
				}
			} while (Menu_Jogo_Velha.display1() != menu.SAIR);
		}

	

	public static void main(String[] args) {
		
		
		menuPrincipal();
		//controle.ctrl_selecionar_ui(menu.display());
	   
	
		
	}

}
