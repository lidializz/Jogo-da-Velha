package jogo_velha;

public class Controle {

	Entidade entidade = new Entidade();
	
	public void ctrl_selecionar_ui(int opcao){
		
		entidade.set_ui();
		
	}


}
