package jogo_velha;

public class Controle {

	Entidade entidade = new Entidade();

	public void selecionar_ui(int opcao) {

		entidade.set_ui();

	}

	public void selecionar_oponente(int opcao) {

		entidade.set_oponente();

	}
	
	public void selecionar_nivel(int opcao) {

		entidade.set_nivel();

	}

	public void iniciarPartida() {

		entidade.iniciarPartida();

	}

}
