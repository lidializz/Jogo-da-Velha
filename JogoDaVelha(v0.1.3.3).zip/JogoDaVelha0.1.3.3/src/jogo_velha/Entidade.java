package jogo_velha;

//import java.util.Scanner;

public class Entidade {
	
	static char[][] matriz = new char[3][3];
	
	public void set_ui(){
		
	}

	public void set_oponente() {		
		
	}
	
	public void set_nivel() {		
		
	}
	
	
	
	public void iniciarPartida(){
		limparPosicoes();
		jogar();
	
	}
	

	private void jogar() {
		//Scanner input = new Scanner(System.in);
		//int jogador1 = 1;
		//int jogador2 = 2;
		gerarTabuleiro(matriz);
		for(int i=0; i<9; i++){
			//le as entradas dos jogadores com o uso do Scanner...
		}
		
	}

	public void limparPosicoes(){
		for (int i=0; i< 3; i++){
			for (int j=0; j<3; j++){
				matriz[i][j]=' ';
			}
				
		}
	
	}
	
	public static void gerarTabuleiro(char matriz[][]){
		System.out.println(matriz[0][0] + "|" + matriz[0][1] + "|"+ matriz[0][2]);
		System.out.println("-----"); 
		System.out.println(matriz[1][0] + "|" + matriz[1][1] + "|"+ matriz[1][2]);
		System.out.println("-----");
		System.out.println(matriz[2][0] + "|" + matriz[2][1] + "|"+ matriz[2][2]);
		
	}//Falta tirar a impressao do tabuleiro da entidade...

}
