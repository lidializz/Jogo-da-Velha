package jogo_velha;

import java.util.Scanner; //Pra poder ler a entrada do console

public class Fronteira {

	public static Controle controle = new Controle();
	static Menu_Jogo_Velha menu = new Menu_Jogo_Velha();
	static Scanner input = new Scanner(System.in);

	/*
	 * Coloquei em um método o case q tinha as interfaces e em uma outra classe
	 * coloquei os níveis..qdo a pessoa escolher o nivel.. pra qualquer opcao
	 * ele inicia a partida
	 */
	
	
	public static void nivelJogo() {

		int opcao;

		do {
			Menu_Jogo_Velha.displayNiveis();
			opcao = input.nextInt();

			switch (opcao) {
			case Menu_Jogo_Velha.FACIL:
				controle.selecionar_nivel(opcao);
				controle.iniciarPartida();
				break;

			case Menu_Jogo_Velha.MEDIO:
				controle.selecionar_nivel(opcao);
				controle.iniciarPartida();
				break;

			case Menu_Jogo_Velha.DIFICIL:
				controle.selecionar_nivel(opcao);
				controle.iniciarPartida();
				break;

			case Menu_Jogo_Velha.VOLTARNIVEL:
				break;

			default:
				System.out.println("OPCAO INVÁLIDA!");
				break;
			}

		} while (opcao != Menu_Jogo_Velha.VOLTARNIVEL);

	}

	public static void interfaceTexto() {
		int opcao;

		do {
			Menu_Jogo_Velha.displayOponente();// aqui o jogador vai escolher o
			// tipo de oponente
			opcao = input.nextInt();
			
			switch (opcao) {
			case Menu_Jogo_Velha.OPONENTE_HUMANO:
				controle.selecionar_oponente(opcao);
				controle.iniciarPartida();
				break;

			case Menu_Jogo_Velha.OPONENTE_ROBO:
				controle.selecionar_oponente(opcao);
				nivelJogo();

				break;

			case Menu_Jogo_Velha.VOLTAR:
				break;

			default:

				System.out.println("OPCAO INVÁLIDA!");
				break;
			}

		} while (opcao != Menu_Jogo_Velha.VOLTAR);
	}

	public static void menuPrincipal() {

		int opcao1, opcao2;

		do {
			Menu_Jogo_Velha.displayMenu();
			opcao1 = input.nextInt();

			switch (opcao1) {

			case Menu_Jogo_Velha.TIPO_INTERFACE:

				do {
					Menu_Jogo_Velha.displayMenuInterface();
					opcao2 = input.nextInt();

					switch (opcao2) {

					case Menu_Jogo_Velha.INTERFACE_GRAFICA:
						System.out.println("Interface n�o dispon�vel\n");
						break;

					case Menu_Jogo_Velha.INTERFACE_TEXTO:
						controle.selecionar_ui(opcao2);
						interfaceTexto();

						break;

					case Menu_Jogo_Velha.VOLTAR:
						break;

					default:

						System.out.println("OPCAO INVÁLIDA!");
						break;
					}
				} while (opcao2 != Menu_Jogo_Velha.VOLTAR);
				break;

			case Menu_Jogo_Velha.SAIR:
				break;

			default:
				System.out.println("OPCAO INV�LIDA!");
				break;
			}
		} while (opcao1 != Menu_Jogo_Velha.SAIR);
	}

	public static void main(String[] args) {

		menuPrincipal();
	}

}