package jogo_velha;

//import java.util.Scanner;

public class Entidade {
	
	static char[][] matriz = new char[5][5];
		
	public void set_ui(){
		
	}

	public void set_oponente() {		
		
	}
	
	public void set_nivel() {		
		
	}
	
	
	
	public void iniciarPartida(){
		jogar();
	}
	

	public static char[][] getMatriz() {
		return matriz;
	}


	private void jogar() {
		//Scanner input = new Scanner(System.in);
		//int jogador1 = 1;
		//int jogador2 = 2;
		//gerarTabuleiro(matriz);
		inicializarTabuleiro(matriz);
		for(int i=0; i<9; i++){
			//le as entradas dos jogadores com o uso do Scanner...
		}
		
	}
	
	public static void inicializarTabuleiro(char matriz[][]){
		for(int i=0; i<5; i=i+2){
			matriz[i][1] = '|';
			matriz[i][3] = '|';
		}
		for(int i=0; i<5; i++){
			matriz[1][i]='-';
			matriz[3][i]='-';
		}
		limparPosicoes(matriz);		
	}
	
	public static void limparPosicoes(char matriz[][]){
		for (int i=0; i< 5; i=i+2){
			for (int j=0; j<5; j=j+2){
				matriz[i][j]=' ';
			}
				
		}
	
	}
			
}
