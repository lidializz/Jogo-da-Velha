package jogo_velha;

public class Menu_Jogo_Velha {

	public static final int TIPO_INTERFACE = 1;
	public static final int SAIR = 2;
	public static final int INTERFACE_GRAFICA = 1;
	public static final int INTERFACE_TEXTO = 2;
	public static final int OPONENTE_HUMANO = 1;
	public static final int OPONENTE_ROBO = 2;
	public static final int VOLTAR = 3;
	public static final int FACIL = 1;
	public static final int MEDIO = 2;
	public static final int DIFICIL = 3;
	public static final int VOLTARNIVEL = 4;

	private static String menuStr = "JOGO DA VELHA JLW\n\n" + 
									"Digite a op��o desejada:\n" + 
									"1 - Tipo de interface\n" + 
									"2 - Sair";
	
	private static String menuInterfaceStr = "Escolha o tipo de interface\n" + 
											 "1 - Interface Gr�fica\n" + 
											 "2 - Interface Texto\n"+ 
											 "3 - Voltar";
	
	private static String menuOponente = "Escolha o tipo de oponente:\n" + 
										 "1 - Oponente Humano\n" + 
										 "2 - Oponente Rob�\n"+ 
										 "3 - Voltar";
	
	private static String menuNiveis = "Escolha o tipo de n�vel:\n" + 
	 								   "1 - F�cil\n" + 
	 								   "2 - M�dio\n"+ 
	 								   "3 - Dif�cil\n" +
	 								   "4 - Voltar";
	
	public static void displayMenu() {

		System.out.println(menuStr);
	}
	
	public static void displayMenuInterface() {

		System.out.println(menuInterfaceStr);
	}
	
	public static void displayOponente() {

		System.out.println(menuOponente);
	}
	
	public static void displayNiveis() {

		System.out.println(menuNiveis);
	}
	
}