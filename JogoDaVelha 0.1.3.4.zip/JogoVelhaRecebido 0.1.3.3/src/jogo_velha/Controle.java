package jogo_velha;

public class Controle {
	
	static char[][] matriz = new char[5][5];

	Entidade entidade = new Entidade();

	public void selecionar_ui(int opcao) {

		entidade.set_ui();

	}

	public void selecionar_oponente(int opcao) {

		entidade.set_oponente();

	}
	
	public void selecionar_nivel(int opcao) {

		entidade.set_nivel();

	}

	public void iniciarPartida() {

		entidade.iniciarPartida();
		matriz = Entidade.getMatriz();

	}
	public static char[][] getMatriz() {
		return matriz;
	}

	public void limparTabuleiro(){
		
	}

}
