package Jogo_da_Velha;

public class Entidade {
	
	public void set_ui(){
		
	}

	public void set_oponente() {
		
		
		
		
		
	}
	
	
	public void iniciarPartida(){
		limparPosicoes();
		gerarTabuleiro();
	
	}
	

	public void limparPosicoes(){
		
	
	}
	

	public void gerarTabuleiro(){
		
	
	}

}
