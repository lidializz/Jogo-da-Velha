package jogo_velha;

import java.util.Scanner; //Pra poder ler a entrada do console

public class Fronteira {

	public static Controle controle = new Controle();
	static Menu_Jogo_Velha menu = new Menu_Jogo_Velha();
	static Scanner input = new Scanner(System.in);

	public static void menuPrincipal() {

		int opcao;

		do {
			Menu_Jogo_Velha.displayMenu();
			opcao = input.nextInt();

			switch (opcao) {

			case Menu_Jogo_Velha.TIPO_INTERFACE:

				do {
					Menu_Jogo_Velha.displayMenuInterface();
					opcao = input.nextInt();

					switch (opcao) {

					case Menu_Jogo_Velha.INTERFACE_GRAFICA:
						System.out.println("Interface não disponível");
						break;
						
					case Menu_Jogo_Velha.INTERFACE_TEXTO:
						controle.selecionar_ui(opcao);
												
						do{
							Menu_Jogo_Velha.displayOponente();// aqui o jogador vai escolher o tipo de oponente
							opcao = input.nextInt();

							switch (opcao) {
								case Menu_Jogo_Velha.OPONENTE_HUMANO:
									controle.selecionar_oponente(opcao);
									break;
									
								case Menu_Jogo_Velha.OPONENTE_ROBO:
									controle.selecionar_oponente(opcao);
									break;
									
								case Menu_Jogo_Velha.VOLTAR:
									break;

								default:

									System.out.println("OPCAO INVÁLIDA!");
									break;
							}
							
						
						}while (opcao != Menu_Jogo_Velha.VOLTAR);
						System.out.println("Gerando tabuleiro...\n\n");
						// mostrar tabuleiro aqui...
						// Entrar no modo de iniciar partida...
						break;

					case Menu_Jogo_Velha.VOLTAR:
						break;

					default:

						System.out.println("OPCAO INVÁLIDA!");
						break;
					}
				} while (opcao != Menu_Jogo_Velha.VOLTAR);
				break;

			case Menu_Jogo_Velha.SAIR:
				break;

			default:
				System.out.println("OPCAO INVÁLIDA!");
				break;
			}
		} while (opcao != Menu_Jogo_Velha.SAIR);
	}

	public static void main(String[] args) {

		menuPrincipal();
	}

}